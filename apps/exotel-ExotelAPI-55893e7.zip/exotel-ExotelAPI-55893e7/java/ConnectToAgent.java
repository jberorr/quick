package com.exotel.Connect;

import com.google.gson.Gson;

import okhttp3.Credentials;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import com.exotel.Connect.*;


public class ConnectToAgent {
	    	public static void main(String[] args) {
	    		ExotelAgent customer = new ExotelAgent();
	    		ExotelResponse res = customer.connectToAgent();
	    	
	}
}





