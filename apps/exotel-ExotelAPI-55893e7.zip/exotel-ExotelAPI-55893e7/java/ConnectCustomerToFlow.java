
package com.exotel.Connect;

public class ConnectCustomerToFlow {
	public static void main(String[] args) {
		ExotelCall calls = new ExotelCall();
		ExotelResponse res = calls.connectCustomerToFlow();
		
	}
}
